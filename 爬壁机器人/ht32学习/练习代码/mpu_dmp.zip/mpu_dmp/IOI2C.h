#ifndef __IOI2C_H
#define __IOI2C_H
#include <HT66F2390.h>
#include "MyType.h"
#define	 SCL		_pf3						//e-Display SCL -> PF7
#define	 SDA		_pf2						//e-Display SDA -> PF6
#define	 SCLC		_pfc3						//PFC7
#define	 SDAC		_pfc2						//PFC6
//#include "sys.h"
//#include "delay.h"



   	   		   
/*IO��������
#define SDA_IN()  SDAC=1
#define SDA_OUT() SDAC=0
*/
	 
 

//IIC���в�������				 
int IIC_Start(void);				//����IIC��ʼ�ź�
void IIC_Stop(void);	  			//����IICֹͣ�ź�
void IIC_Send_Byte(u8 txd);			//IIC����һ���ֽ�
u8 IIC_Read_Byte(unsigned char ack);//IIC��ȡһ���ֽ�
int IIC_Wait_Ack(void); 				//IIC�ȴ�ACK�ź�
void IIC_Ack(void);					//IIC����ACK�ź�
void IIC_NAck(void);				//IIC������ACK�ź�

void IIC_Write_One_Byte(u8 daddr,u8 addr,u8 data);
u8 IIC_Read_One_Byte(u8 daddr,u8 addr);	 
unsigned char I2C_Readkey(unsigned char I2C_Addr);

unsigned char I2C_ReadOneByte(unsigned char I2C_Addr,unsigned char addr);
unsigned char IICwriteByte(unsigned char dev, unsigned char reg, unsigned char data);
u8 IICwriteBytes(u8 dev, u8 reg, u8 length, u8* data);
u8 IICwriteBits(u8 dev,u8 reg,u8 bitStart,u8 length,u8 data);
u8 IICwriteBit(u8 dev,u8 reg,u8 bitNum,u8 data);
u8 IICreadBytes(u8 dev, u8 reg, u8 length, u8 *data);
void delay_ms(unsigned long num_ms);
void get_ms(unsigned long *count);
int i2cWrite(u8 addr, u8 reg, u8 len, u8 *data);
int i2cRead(u8 addr, u8 reg, u8 len, u8 *buf);

#endif

//------------------End of File----------------------------
