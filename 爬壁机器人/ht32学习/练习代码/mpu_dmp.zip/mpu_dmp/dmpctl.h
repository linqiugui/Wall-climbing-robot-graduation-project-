#ifndef _DMPCTL_H
#define _DMPCTL_H
#include <HT66F2390.h>
u8 mpu6050_dmp_init(void)	;
u8 DMP_getdate(void) ;
extern float Yaw,Roll,Pitch;
#endif





